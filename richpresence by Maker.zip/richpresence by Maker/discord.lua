Citizen.CreateThread(function()
	while true do

	local count = 0

local text = {
"Serious RP",
"Venez découvrir le serveur",
"Serious Staff" 
}

		for _, __ in pairs(text) do 
			count = count + 1
		end
	
		local presence  = math.random(1, count)
	
		local player = GetPlayerPed(-1)
	
		SetDiscordAppId('Votre discord id (https://discordapp.com/developers/applications)')
		SetDiscordRichPresenceAsset('logo')
		SetDiscordRichPresenceAssetText('Nom du server')
		SetDiscordRichPresenceAssetSmall('logo')
		SetDiscordRichPresenceAssetSmallText('https://discord.gg/wJryrVP')
		
		while true do
        Citizen.Wait(1500)
        players = {}
        for i = 0, 128 do
            if NetworkIsPlayerActive( i ) then
                table.insert( players, i )
            end
        end
        SetRichPresence("‍"..GetPlayerName(PlayerId()) .. " - ID : " ..GetPlayerServerId(PlayerId()).. " - " .. #players .. "/128 Joueurs")
	end
	
	--	SetRichPresence((GetPlayerName(PlayerId())) .. " -") -- [Steam username] [text]
	--	SetRichPresence("".. text[presence] .."")  -- [text]
		SetDiscordRichPresenceAssetText('https://discord.gg/wJryrVP')
		print('^5Discord rich presence mis a jour :D')
		Citizen.Wait(300000) -- 5 minutes 
	end
end)

--######-----[RichPresence by Maker ツ]-----########--