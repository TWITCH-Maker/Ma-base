fx_version 'adamant'
game 'gta5'

description 'Custom Discord Rich Presence by Mike'

client_script 'discord.lua'